const modeWhitelist = document.getElementById('modeWhitelist');
const modeCleanlist = document.getElementById('modeCleanlist');

const siteInput = document.getElementById('siteInput');
const addBtn = document.getElementById('addBtn');
const siteList = document.getElementById('siteList');

const cleanInput = document.getElementById('cleanInput');
const addCleanBtn = document.getElementById('addCleanBtn');
const cleanList = document.getElementById('cleanList');

function renderList(list, container, storageKey) {
  container.innerHTML = '';
  list.forEach((site, index) => {
    const li = document.createElement('li');
    li.textContent = site + ' ';

    const delBtn = document.createElement('button');
    delBtn.textContent = 'Remove';
    delBtn.onclick = () => {
      list.splice(index, 1);
      const update = {};
      update[storageKey] = list;
      chrome.storage.sync.set(update);
      renderList(list, container, storageKey);
    };

    li.appendChild(delBtn);
    container.appendChild(li);
  });
}

function updateModeUI(mode) {
  if (mode === 'whitelist') {
    modeWhitelist.checked = true;
    modeCleanlist.checked = false;
    siteInput.disabled = false;
    addBtn.disabled = false;
    cleanInput.disabled = true;
    addCleanBtn.disabled = true;
  } else {
    modeWhitelist.checked = false;
    modeCleanlist.checked = true;
    siteInput.disabled = true;
    addBtn.disabled = true;
    cleanInput.disabled = false;
    addCleanBtn.disabled = false;
  }
}

modeWhitelist.addEventListener('change', () => {
  if (modeWhitelist.checked) {
    chrome.storage.sync.set({ mode: 'whitelist' }, () => {
      updateModeUI('whitelist');
    });
  }
});

modeCleanlist.addEventListener('change', () => {
  if (modeCleanlist.checked) {
    chrome.storage.sync.set({ mode: 'cleanlist' }, () => {
      updateModeUI('cleanlist');
    });
  }
});

addBtn.onclick = () => {
  const newSite = siteInput.value.trim();
  if (!newSite) return;
  chrome.storage.sync.get('whitelist', ({ whitelist }) => {
    if (!whitelist.includes(newSite)) {
      whitelist.push(newSite);
      chrome.storage.sync.set({ whitelist });
      renderList(whitelist, siteList, 'whitelist');
      siteInput.value = '';
    }
  });
};

addCleanBtn.onclick = () => {
  const newSite = cleanInput.value.trim();
  if (!newSite) return;
  chrome.storage.sync.get('cleanlist', ({ cleanlist }) => {
    if (!cleanlist.includes(newSite)) {
      cleanlist.push(newSite);
      chrome.storage.sync.set({ cleanlist });
      renderList(cleanlist, cleanList, 'cleanlist');
      cleanInput.value = '';
    }
  });
};

chrome.storage.sync.get(['whitelist', 'cleanlist', 'mode'], (data) => {
  renderList(data.whitelist || [], siteList, 'whitelist');
  renderList(data.cleanlist || [], cleanList, 'cleanlist');
  updateModeUI(data.mode || 'whitelist');
});

// 🔥 Auto-reload si le shortcut "switch-mode" est utilisé
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "modeSwitched") {
    if (window.location.href.includes("options.html")) {
      window.location.reload();
    }
  }
});
