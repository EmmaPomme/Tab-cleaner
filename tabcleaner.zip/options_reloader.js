chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "modeSwitched") {
    if (window.location.href.includes("options.html")) {
      window.location.reload();
    }
  }
});
