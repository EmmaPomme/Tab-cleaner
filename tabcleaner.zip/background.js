let lastNotificationId = null;
let notificationBurstCount = 0;
let burstTimer = null;

function cleanTabs() {
  chrome.storage.sync.get(['mode', 'whitelist', 'cleanlist'], (data) => {
    const { mode, whitelist = [], cleanlist = [] } = data;

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        const shouldClose = mode === 'whitelist'
          ? !whitelist.some(domain => tab.url.includes(domain))
          : cleanlist.some(domain => tab.url.includes(domain));

        if (shouldClose) {
          chrome.tabs.remove(tab.id);
        }
      });
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    mode: 'whitelist',
    whitelist: ["youtube.com"],
    cleanlist: []
  });
});

chrome.action.onClicked.addListener(() => {
  cleanTabs();
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "clean-tabs") {
    cleanTabs();
  }

  if (command === "switch-mode") {
    chrome.storage.sync.get("mode", ({ mode }) => {
      const newMode = mode === "whitelist" ? "cleanlist" : "whitelist";
      chrome.storage.sync.set({ mode: newMode }, () => {

        // 🚨 Gestion anti-spam
        if (notificationBurstCount >= 5) {
          console.log("Too many notifications in short time, ignoring...");
          return;
        }

        notificationBurstCount++;

        if (burstTimer) {
          clearTimeout(burstTimer);
        }
        burstTimer = setTimeout(() => {
          notificationBurstCount = 0;
        }, 1000);

        if (lastNotificationId) {
          chrome.notifications.clear(lastNotificationId);
        }

        chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "Tab Cleaner",
          message:
            "Switched to: " +
            (newMode === "whitelist"
              ? "Keep only those tabs"
              : "Close only those tabs")
        }, (notificationId) => {
          lastNotificationId = notificationId;
        });

        chrome.tabs.query({}, (tabs) => {
          tabs.forEach((tab) => {
            chrome.tabs.sendMessage(tab.id, { action: "modeSwitched" }).catch(() => {});
          });
        });
      });
    });
  }

  if (command === "show-current-mode") {
    chrome.storage.sync.get("mode", ({ mode }) => {
      const currentMode = mode === "whitelist" ? "Keep only those tabs" : "Close only those tabs";

      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "Tab Cleaner",
        message: "Current mode: " + currentMode
      }, (notificationId) => {
        setTimeout(() => {
          chrome.notifications.clear(notificationId);
        }, 2000); // Notification disparaît après 2 secondes
      });
    });
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "cleanTabs") {
    cleanTabs();
  }
});
